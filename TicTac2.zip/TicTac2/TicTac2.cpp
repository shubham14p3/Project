// TicTac2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include"MainGame.h"


int main()
{
	MainGame mainGame;
	mainGame.run();

    return 0;
}

