#pragma once
#include"Board.h"
#include <stdlib.h>
class Amateur {
public:
	void move(Board& board, int amateurPlayer);
	Amateur();
	~Amateur();
};

