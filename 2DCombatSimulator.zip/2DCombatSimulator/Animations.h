#pragma once
#include<string>
using namespace std;

class Animations
{

public:
	Animations();
	void bigSign();
	void loading(string text, string color);

};

