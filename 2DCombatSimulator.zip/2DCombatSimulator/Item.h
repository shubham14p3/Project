#pragma once
#include<string>

using namespace std;

class Item
{
public:
	Item(string itemName, int count, int value, int dgmBonus, int hpBonus);// tmpHp for grocery
	~Item();

	//setters

	void setName(string name);
	void setProperties(int hp, int dmg, int count, int value);
	void setCount(int count){ _count = count; }

	//getters
	string getName(){ return _itemName; }
	int getValue(){ return _value; }
	int getDMG(){ return _dmgBonus; }
	int getHP(){ return _hpBonus; }
	int getCount(){ return _count; }


	void addOne() { _count++; }
	void removeOne() { _count--; }

	//items properties

	void addDMG();
	void addHP();
	void addSPD();
private:

	string _itemName;
	int _dmgBonus;
	int _hpBonus;
	int _value;
	int _count;
};

