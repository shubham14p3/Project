#include "Item.h"


Item::Item(string itemName, int count, int value, int dmgBonus, int hpBonus)
{
	_itemName = itemName;
	_value = value;
	_dmgBonus = dmgBonus;
	_hpBonus = hpBonus;
	_count = count;


}


Item::~Item()
{
}

void Item::setProperties(int hp,  int dmg,int count, int value){

	_dmgBonus = dmg;
	_hpBonus = hp;
	_value = value;
	_count = count;
}
void Item::setName(string name){
	_itemName = name;
}