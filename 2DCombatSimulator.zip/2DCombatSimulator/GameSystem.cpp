#include "GameSystem.h"
#include<random>
#include<ctime>
#include<conio.h>
#include<iostream>
#include<Windows.h>

using namespace std;


GameSystem::GameSystem()
{
}

void GameSystem::intro(){
	_animation.bigSign();
	
}
void GameSystem::analizeMap(){
	vector<string> board;
	default_random_engine randomGenerator(time(NULL));
	uniform_int_distribution<int> unitsNumber(10, 25);

	_level[0].getBoard(board);

	
	for (unsigned i = 0; i < board.size(); i++){
		for (unsigned j = 0; j < board[i].size(); j++){
			if (board[i][j] == 'P'){
				_players[_pNumber].setStats("Me", 100, 50, 100);
				_players[_pNumber].setPosition(j, i);
				_players[_pNumber].setSoldiers();
				_pNumber++;
				i = board.size()-1;
			}
		}
	}
	for (unsigned i = 0; i < board.size(); i++){
		for (unsigned j = 0; j < board[i].size(); j++){
			if (board[i][j] == 'M'){
				_players[_pNumber].setStats("Bandit", 70, 20, unitsNumber(randomGenerator));
				_players[_pNumber].setPosition(j, i);
				_players[_pNumber].setSoldiers();
				_pNumber++;
			}

		}
	}
}
void GameSystem::play(){
	intro();
	bool gameOver = false;
	bool endOfBattle = false;
	bool fight = false;
	unsigned mX, mY, pX, pY;
	default_random_engine randomGenerator(time(NULL));
	uniform_int_distribution<int> moveNumber(0, 10);
	_level[0].load("level1.txt");//przygoda
	_level[1].fill0();
	analizeMap();
	_level[0].initShops();
	bool following = false;
	
	while (gameOver == false){
		if (_players[0].getDead() == true)
			break;
		system("cls");
		_level[0].printCamera(_players[0]);
		_level[0].moveMe(_players[0], fight);
		if (fight == true){
			_players[0].getPosition(pX, pY);
			for (unsigned i = 1; i < _pNumber; i++){
				_players[i].getPosition(mX, mY);
				
				if (mX == pX && mY == pY){
					_level[1].FIGHT(_players[0], _players[i]);
					fight = false;
					break;
				}
			}
		}
		if (_players[0].getDead() == true)
			break;
		for (unsigned i = 1; i < _pNumber; i++){

			if (_players[0].getDead() == true)
				break;

			if (_players[i].getDead() == true)
				continue;


			_level[0].follow(_players[0], _players[i], following, fight);

			if (fight == true){
				_level[1].FIGHT(_players[0], _players[i]);
				fight = false;
			}

			if (following == false)
				_level[0].moveMonster(_players[i], moveNumber(randomGenerator));
			
		}

		
	}
}

//checkers

void GameSystem::checkPlayers(){
	for (unsigned i = 0; i < _pNumber; i++){
		_players[i].printPlayer();
	}

}