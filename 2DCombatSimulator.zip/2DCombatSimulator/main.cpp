#include"GameSystem.h"

#include<conio.h>
#include<iostream>


// Player and his branches - checked
// reading maps and location of branches on the map - checked
// getting around - checked
// battle of branches:
// other colors - checked
// attacking the nearest opponent located - to improve, you have to change _enemies, _allies with each move
// surround the opponent
// fight comments optional

using namespace std;

int main()
{
	GameSystem gamesystem;
	gamesystem.play();

	printf("\n YOU LOST THE GAME\n Click button to exit\n");
	_getch();
}