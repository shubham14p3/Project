#pragma once
#include"Players.h"

#include<vector>
#include<string>
#include"Shop.h"


using namespace std;

class Level
{
public:
	Level();
	// setters
	void load(string name); 
	void setColor(char mark, string color);
	void setStringColor(string text, string Color);
	void setPoint(unsigned x, unsigned y, char mark);
	// getters
	void getBoard(vector<string> & board);
	char getTile(unsigned x, unsigned y);



	//others
	void print_enemies();
	void print_allies();
	void printMap();
	void printCamera(Players & player);
	void fill0();
	void deleteBoard();
	
	

	// MOVING
	void moveMe(Players & player, bool & fight);
	bool processMyMove(Players & player,char tile, bool & fight);
	void moveMonster(Players & player, unsigned random);
	bool processPlayerMoveF(char tile, bool & fight);
	bool processPlayerMove(char tile);
	void follow(Players & player, Players & enemy, bool & following, bool & fight);
	

	//battle
	void setFightBoard(Players & player1, Players & player2);
	void printBattleMap(unsigned playerX, unsigned playerY, unsigned monsterX, unsigned monsterY);
	void processingBattle(Players & player, Players & enemy);
	void randomMovePlayer(int &x, int &y,  unsigned sx, unsigned sy, unsigned dx, unsigned dy);
	void randomMoveEnemy(int &x, int &y, unsigned sx, unsigned sy, unsigned dx, unsigned dy);
	void FIGHT(Players & player1, Players & player2);
	void randomMove();

	//Menu
	void initShops();
	void enterShops(Players & player);
	void enterItems(Players & player);
	void enterSoldiers(Players & player);
	void Menu(vector<string> words, Players & player);
private:
	vector<string> _board;
	vector<Shop> _shops;
	unsigned _enemies[40][60];
	unsigned _allies[40][60];
};

