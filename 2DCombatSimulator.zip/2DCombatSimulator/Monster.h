#pragma once

#include<string>

using namespace std;

class Monster
{
public:
	Monster();

	//setters

	void setStats(string name, unsigned hp, unsigned damage);
	void setPosition(unsigned x, unsigned y);
	void setGood(){ _evil = false; }
	void setEvil(){ _evil = true; }
	void setLive(){ _dead = false; }
	void setDead(){ _dead = true; }

	void addAtrb(int hp, int damage){ _hp += hp; _damage += damage; }

	
	//getters

	void getPosition(unsigned &x, unsigned & y);
	unsigned getX(){ return _x; }
	unsigned getY(){ return _y; }
	bool getEvil(){ return _evil; }
	bool getDead(){ return _dead; }
	unsigned getHp(){ return _hp; }
	unsigned getDamage(){ return _damage; }
	string getName(){ return _name; }
	
	unsigned attack();
	void receiveDmg(unsigned attack, bool & dead);

	char getMark();

	void printStats();
private:
	bool _evil;
	bool _dead;
	string _name;
	unsigned _hp;
	unsigned _damage;
	unsigned _x;
	unsigned _y;



};

