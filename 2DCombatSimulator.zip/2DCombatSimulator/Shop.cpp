#include "Shop.h"


Shop::Shop(string name, int money)
{
	_name = name;
	_money = money;
}


Shop::~Shop()
{
}

void Shop::getItemNames(vector<string> & itemNames){
	list<Item>::iterator it;
	for (it = _items.begin(); it != _items.end(); it++){
		itemNames.push_back((*it).getName());
	}
}
bool Shop::purchaseItem(Item newItem){

	list < Item > ::iterator lit;

	for (lit = _items.begin(); lit != _items.end(); lit++){
		if ((*lit).getName() == newItem.getName()){
			if (_money >= newItem.getValue()){
				(*lit).addOne();
				substractMoney(-newItem.getValue());
				return true;
			}
			else{
				printf("\n Shop has noy enough money to deal\n");
				_getch();
				return false;
			}

		}
	}

	if (_money >= newItem.getValue()){
		_items.push_back(newItem);
		substractMoney(-newItem.getValue());
	}
	return true;

}
void Shop::sellItem(int number, Item & newItem){

	list<Item>::iterator lit;
	unsigned i = 0;

	for (lit = _items.begin(); lit != _items.end(); lit++){

		i++;
		if (i == number){
			/*newItem.setName((*lit).getName());
			newItem.setProperties((*lit).getHP(), (*lit).getTMPHP(), (*lit).getDMG(), (*lit).getSPD(), (*lit).getCount(), (*lit).getValue());*/

			newItem = (*lit);
			newItem.setCount(1);
			substractMoney(newItem.getValue());


			if ((*lit).getCount() == 1){
				_items.erase(lit);
				return;
			}
			(*lit).removeOne();

		}
	}


}
void Shop::showItems(){

	list<Item>::iterator lit;

	printf("****WELCOME IN %s SHOP****\n", _name.c_str());
	for (lit = _items.begin(); lit != _items.end(); lit++){
		printf("%s\tValue: %d\n",  (*lit).getName().c_str(), (*lit).getValue());
		printf("HP:%d\tDMG:%d\n", (*lit).getHP(), (*lit).getDMG());
		
	}
}