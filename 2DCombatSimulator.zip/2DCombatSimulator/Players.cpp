#include "Players.h"
#include<random>
#include<ctime>
#include<Windows.h>
#include<conio.h>

default_random_engine randomGenerator(time(NULL));
uniform_int_distribution<int> number(1, 3);
uniform_int_distribution<int> attack(2, 6);
uniform_int_distribution<int> health(15, 30);
Players::Players()
{
	_money = 300;
	_exp = 0;
	_maxExp = 100;
	_level = 1;
}

//setters
void Players::setPosition(unsigned x, unsigned y){
	_x = x;
	_y = y;
}
void Players::setFightPosition(unsigned x, unsigned y){
	_fx = x;
	_fy = y;
}
void Players::setStats(string name, unsigned hp, unsigned damage, unsigned units){
	_name = name;
	_hp = hp;
	_damage = damage;
	_units = units;
	if (_name == "Me"){
		for (unsigned i = 0; i < _units; i++){
			monsters[i].setGood();
			monsters[i].setLive();
		}
	}
	else{
		for (unsigned i = 0; i < _units; i++){
			monsters[i].setEvil();
			monsters[i].setLive();
		}
	}
}
void Players::setMonsterPosition(unsigned x, unsigned y, unsigned nm){
	monsters[nm].setPosition(x, y);
}
void Players::setSoldiers(){
	unsigned nm = 0;
	
	unsigned random;

	for (unsigned i = 0; i < _units; i++){
		random = number(randomGenerator);
		switch (random){
		case 1:
			_snakes++;
			break;
		case 2:
			_zombies++;
			break;
		case 3:
			_dragons++;
			break;
		}
	}
	for (unsigned i = 0; i < _units; i++){
		if (i < _snakes){
			monsters[nm].setStats("Snake", health(randomGenerator), attack(randomGenerator));
			nm++;
			continue;
		}
		if (i < _snakes + _zombies){
			monsters[nm].setStats("Zombie", health(randomGenerator)+ 20, attack(randomGenerator) +5);
			nm++;
			continue;
		}
		
		monsters[nm].setStats("Dragon", health(randomGenerator)+50, attack(randomGenerator)+15);
			nm++;

	}

}
void Players::addAtrb(int hp, int damage){
	for (unsigned i = 0; i < _units; i++){
		monsters[i].addAtrb(hp, damage);
	}
}

//getters

void Players::getPosition(unsigned & x, unsigned & y){
	x = _x;
	y = _y;
}
void Players::getFightPosition(unsigned & x, unsigned & y){
	x = _fx;
	y = _fy;
}
void Players::getMonsterPosition(unsigned & x, unsigned & y, unsigned nm){
	monsters[nm].getPosition(x, y);
}
unsigned Players::getMonsterX(unsigned number){
	return monsters[number].getX();
}
unsigned Players::getMonsterY(unsigned number){
	return monsters[number].getY();
}
void Players::getUnits(unsigned & snakes, unsigned & zombies, unsigned & dragons){
	snakes = _snakes;
	zombies = _zombies;
	dragons = _dragons;
}

//checkers

void Players::printPlayer(){
	printf("\nPosition (%d,%d)\nName : %s\nExperience : %d/%d\nMoney: %d\nHP : %d\nDamage : %d\nUnits: %d\nDragons: %d\nZombies: %d\nSnakes: %d\n", _x, _y, _name.c_str(),_exp, _maxExp, _money, _hp, _damage, _units, _dragons, _zombies, _snakes);
	
}

void Players::printMonsters(){
	printf("\n\n\n Name\tHp\tDamage\n");
	for (unsigned i = 0; i < _units; i++){
		printf("%s\t%d\t%d\n", monsters[i].getName().c_str(), monsters[i].getHp(), monsters[i].getDamage());
	}
}
void Players::monsterDead(unsigned & numberOfMonster){
	
	//monsters[numberOfMonster] = monsters[_units - 1];
	//numberOfMonster--;
	//_units--;
}
bool Players::checkMonsterDead(unsigned number){
	return monsters[number].getDead();
}
void Players::checkAndSortArmy(){
	unsigned nm = 0;
	unsigned snakes=0, zombies=0, dragons=0;
	for (unsigned i = 0; i < _units; i++){
		if (monsters[i].getDead() == true)
			continue;

		if (getMonsterMark(i) == 'S'){
			snakes++;
		}

		if (getMonsterMark(i) =='Z'){
			zombies++;
		}

		if (getMonsterMark(i) == 'D'){
			dragons++;
		}
	}
	_snakes = snakes;
	_zombies = zombies;
	_dragons = dragons;
	_units = _zombies + _snakes + _dragons;
	
	for (unsigned i = 0; i < _units; i++){
		if (i < _snakes){
			monsters[nm].setStats("Snake", health(randomGenerator), attack(randomGenerator));
			nm++;
			continue;
		}
		if (i < _snakes + _zombies){
			monsters[nm].setStats("Zombie", health(randomGenerator) + 20, attack(randomGenerator) + 5);
			nm++;
			continue;
		}

		monsters[nm].setStats("Dragon", health(randomGenerator) + 50, attack(randomGenerator) + 15);
		nm++;



	}
	
}
char Players::getMonsterMark( unsigned number){
	return monsters[number].getMark();
}
void Players::printMonster(unsigned number){
	monsters[number].printStats();
}

void Players::getMonsterAttack(unsigned attack, unsigned number, bool & dead){
	monsters[number].receiveDmg(attack, dead);

	//printf("%s zaatakowal wartoscia %d z pozcyji (%d,%d)\n", monsters[number].getName().c_str(), attack, getMonsterX(number), getMonsterY(number));
	//_getch();
	if (dead == true){
		monsters[number].setDead();
	}
}
unsigned Players::attackMonster( unsigned number){
	return monsters[number].attack();
}
void Players::getMonstersStats(){
	for (unsigned i = 0; i < _units; i++){
		if (monsters[i].getDead() == true)
			continue;

		monsters[i].printStats();
	}
	
}
void Players::addSnake(){
	if (_units >= 100){
		printf("\nYou cant have more 100 soldiers !!\n");
		return;
	}
	_units++;
	_snakes++;
	monsters[_units - 1].setStats("Snake", health(randomGenerator), attack(randomGenerator));
	checkAndSortArmy();

}
void Players::addZombie(){
	if (_units >= 100){
		printf("\nYou cant have more 100 soldiers !!\n");
		return;
	}
	_units++;
	_zombies++;

	monsters[_units - 1].setStats("Zombie", health(randomGenerator) + 20, attack(randomGenerator) + 5);
	checkAndSortArmy();
}
void Players::addDragon(){
	if (_units >= 100){
		printf("\nYou cant have more 100 soldiers !!\n");
		return;
	}
	_units++;
	_dragons++;

	monsters[_units - 1].setStats("Dragon", health(randomGenerator) + 50, attack(randomGenerator) + 15);
	checkAndSortArmy();
}
void Players::checkLvlUp(){
	if (_exp >= _maxExp){
		_exp -= _maxExp;
		_maxExp += 75;
		_money += 500;
		_damage += 9;
		_hp += 50;
		_level++;
		for (unsigned i = 0; i < _level; i++){



			if (_snakes <40)
				addSnake();
			else{
				if (_dragons <40)
					addDragon();
				else{
					if (_zombies<40)
						addZombie();
				}
			}


			if (_zombies<40)
				addZombie();
			else{
				if (_snakes <40)
					addSnake();
				else{
					if (_dragons<40)
						addDragon();
				}
			}

			if (_dragons<40 )
				addDragon();
			else{
				if (_snakes <40)
					addSnake();
				else{
					if (_zombies<40)
						addZombie();
				}
			}

			
		}

		printf("\n\n LEVEL UP !!! \nYou Money: + 500\nSoldiers: +3*lvl \n\n");
		system("PAUSE");

	}
}