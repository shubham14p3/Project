#include "Monster.h"
#include<random>
#include<Windows.h>
#include<ctime>
#include<iostream>

Monster::Monster()
{
	_x = 0;
	_y = 0;
	
}

//setters
void Monster::setPosition(unsigned x, unsigned y){
	_x = x;
	_y = y;
}
void Monster::setStats(string name, unsigned hp, unsigned damage ){
	_name = name;
	_hp = hp;
	_damage = damage;
	_dead = false;
}

//getters
void Monster::getPosition(unsigned & x, unsigned & y){
	x = _x;
	y = _y;
}
unsigned Monster::attack(){
	default_random_engine randomGenerator(time(NULL));
	uniform_int_distribution<int> number(1, 100);
	if (number(randomGenerator) > 85)
		return _damage * 2;
	else
		return _damage;
}
void Monster::receiveDmg(unsigned attack, bool &dead){
	if ((int)(_hp - attack) <= 0){
		_hp = 0;
		_dead = true;
		dead = true;
	}	
	else
		_hp -= attack;
}
char Monster::getMark(){
	return _name[0];
}
void Monster::printStats(){
	printf("Name : %s Hp:%d  Damage:%d  Position :(%d,%d)\n", _name.c_str(), _hp, _damage, _x, _y);
}