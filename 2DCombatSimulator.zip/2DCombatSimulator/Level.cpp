#include "Level.h"

#include<fstream>
#include<ctime>
#include<random>
#include<conio.h>
#include<Windows.h>
#include<iostream>
#include<cmath>

using namespace std;


Level::Level()
{
}

//setters 

void Level::load(string name){
	ifstream file;

	file.open(name);

	if (file.fail()){
		perror(name.c_str());
		exit(1);
	}
	string input;
	while (getline(file, input)){
		_board.push_back(input);

	}
}
void Level::setPoint(unsigned x, unsigned y, char mark){
	_board[y][x] = mark;
}
void Level::setColor(char mark, string Color){
	HANDLE hOut;
	hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	if (Color == "red")
		SetConsoleTextAttribute(hOut, FOREGROUND_RED | FOREGROUND_INTENSITY);
	if (Color == "blue")
		SetConsoleTextAttribute(hOut, FOREGROUND_BLUE | FOREGROUND_INTENSITY);
	if (Color == "green")
		SetConsoleTextAttribute(hOut, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
	if (Color == "gold")
		SetConsoleTextAttribute(hOut, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
	if (Color == "violet")
		SetConsoleTextAttribute(hOut, FOREGROUND_BLUE | FOREGROUND_RED | FOREGROUND_INTENSITY);

	cout << mark; 

	SetConsoleTextAttribute(hOut, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_RED | FOREGROUND_INTENSITY);
}
void Level::setStringColor(string text, string Color){
	HANDLE hOut;
	hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	if (Color == "red")
		SetConsoleTextAttribute(hOut, FOREGROUND_RED | FOREGROUND_INTENSITY);
	if (Color == "blue")
		SetConsoleTextAttribute(hOut, FOREGROUND_BLUE | FOREGROUND_INTENSITY);
	if (Color == "green")
		SetConsoleTextAttribute(hOut, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
	if (Color == "gold")
		SetConsoleTextAttribute(hOut, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
	if (Color == "violet")
		SetConsoleTextAttribute(hOut, FOREGROUND_BLUE | FOREGROUND_RED | FOREGROUND_INTENSITY);

	cout << text << endl;

	SetConsoleTextAttribute(hOut, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_RED | FOREGROUND_INTENSITY);
}
void Level::fill0(){
	for (unsigned i = 0; i < 40; i++){
		for (unsigned j = 0; j < 60; j++){
			_enemies[i][j] = 0;
			_allies[i][j] = 0;
		}
	}
}
//getters

void Level::getBoard(vector<string> & board){
	for (unsigned i = 0; i < _board.size(); i++){
		board.push_back(_board[i]);
	}
}
char Level::getTile( unsigned x, unsigned y){
	return _board[y][x];
}
//others

void Level::print_enemies(){
	for (unsigned i = 0; i < _board.size(); i++){
		for (unsigned j = 0; j < _board[i].size(); j++){
			printf("%d" , _enemies[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}
void Level::print_allies(){
	for (unsigned i = 0; i < _board.size(); i++){
		for (unsigned j = 0; j < _board[i].size(); j++){
			printf("%d", _allies[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}
void Level::printMap(){
	
	for (unsigned i = 0; i < _board.size(); i++){
		printf("%d\t%s\n", i,_board[i].c_str());
	}
}

void Level::printCamera(Players & player){
	cout << "\n\n\n\n\n";
	for (int i = player.getY() - 4; i < player.getY() + 4; i++){
		cout << "\n\t\t";
		for (int j = player.getX() - 10; j < player.getX() + 10; j++){
			if (i >= 0 && j >= 0 && i<_board.size() && j< _board[i].size()){
				cout  <<_board[i][j];
			}
		}
	}

	cout << endl << endl << endl << "\t\tM -> Menu" << endl;

	player.printPlayer();
}
void Level::deleteBoard(){
	
		_board.clear();
	
}

//MOVING
void Level::moveMe(Players & player, bool & fight){
	
	char click;

	vector<string> words;
	words.push_back("Player");
	words.push_back("Shops");
	words.push_back("Back");
	click = _getch();
	unsigned playerX, playerY;
	player.getPosition(playerX, playerY);
	char tile;
	switch (click)
	{
	case 'm':
	case 'M':
		Menu(words, player);
		break;
	case 'z':
	case 'Z':
		tile = _board[playerY + 1][playerX - 1];
		if (processMyMove(player, tile, fight) == true){
			player.setPosition(playerX - 1, playerY + 1);
			_board[playerY][playerX] = ' ';
			_board[playerY + 1][playerX - 1] = 'P';
		}break;
	case 'x':
	case 'X':
	case 's':
	case 'S':
		tile = _board[playerY + 1][playerX];
		if (processMyMove(player, tile, fight) == true){
			player.setPosition(playerX, playerY + 1);
			_board[playerY][playerX] = ' ';
			_board[playerY + 1][playerX] = 'P';
		}break;
	case 'c':
	case 'C':
		tile = _board[playerY + 1][playerX + 1];
		if (processMyMove(player, tile, fight) == true)
		{
			player.setPosition(playerX + 1, playerY + 1);
			_board[playerY][playerX] = ' ';
			_board[playerY + 1][playerX + 1] = 'P';
		} break;
	case 'a':
	case 'A':
		tile = _board[playerY][playerX - 1];
		if (processMyMove(player, tile, fight) == true)
		{
			player.setPosition(playerX - 1, playerY);
			_board[playerY][playerX] = ' ';
			_board[playerY][playerX - 1] = 'P';
		}break;

	case 'd':
	case 'D':
		tile = _board[playerY][playerX + 1];
		if (processMyMove(player, tile, fight) == true)
		{
			player.setPosition(playerX + 1, playerY);
			_board[playerY][playerX] = ' ';
			_board[playerY][playerX + 1] = 'P';
		}break;
	case 'q':
	case 'Q':
		tile = _board[playerY - 1][playerX - 1];
		if (processMyMove(player, tile, fight) == true)
		{
			player.setPosition(playerX - 1, playerY - 1);
			_board[playerY][playerX] = ' ';
			_board[playerY - 1][playerX - 1] = 'P';
		}break;
	case 'w':
	case 'W':
		tile = _board[playerY - 1][playerX];
		if (processMyMove(player, tile, fight) == true)
		{
			player.setPosition(playerX, playerY - 1);
			_board[playerY][playerX] = ' ';
			_board[playerY - 1][playerX] = 'P';
		} break;
	case 'e':
	case 'E':
		tile = _board[playerY - 1][playerX + 1];
		if (processMyMove(player, tile, fight) == true)
		{
			player.setPosition(playerX + 1, playerY - 1 );
			_board[playerY][playerX] = ' ';
			_board[playerY - 1][playerX + 1] = 'P';
		}break;
	default:
		printf("\n Wrong input!!\n"); break;
	}

}
void Level::moveMonster(Players & player, unsigned random){
	unsigned monsterX, monsterY;
	player.getPosition(monsterX, monsterY);
	unsigned mark;
	char tile;
	bool fight;
	switch (random){
	case 1: tile = _board[monsterY + 1][monsterX - 1];
		if (processPlayerMoveF(tile, fight) == true){
			player.setPosition(monsterX - 1, monsterY + 1);
			_board[monsterY][monsterX] = ' ';
			_board[monsterY + 1][monsterX - 1] = 'M';
		}break;
	case 2:
		tile = _board[monsterY + 1][monsterX];
		if (processPlayerMoveF(tile, fight) == true){
			player.setPosition(monsterX, monsterY + 1);
			_board[monsterY][monsterX] = ' ';
			_board[monsterY + 1][monsterX] = 'M';
		}break;
	case 3:
		tile = _board[monsterY + 1][monsterX + 1];
		if (processPlayerMoveF(tile, fight) == true)
		{
			player.setPosition(monsterX + 1, monsterY + 1);
			_board[monsterY][monsterX] = ' ';
			_board[monsterY + 1][monsterX + 1] = 'M';
		} break;
	case 4:
		tile = _board[monsterY][monsterX - 1];
		if (processPlayerMoveF(tile, fight) == true)
		{
			player.setPosition(monsterX - 1, monsterY);
			_board[monsterY][monsterX] = ' ';
			_board[monsterY][monsterX - 1] = 'M';
		}break;

	case 6:
		tile = _board[monsterY][monsterX + 1];
		if (processPlayerMoveF(tile, fight) == true)
		{
			player.setPosition(monsterX + 1, monsterY);
			_board[monsterY][monsterX] = ' ';
			_board[monsterY][monsterX + 1] = 'M';
		}break;
	case 7:
		tile = _board[monsterY - 1][monsterX - 1];
		if (processPlayerMoveF(tile, fight) == true)
		{
			player.setPosition(monsterX - 1, monsterY - 1);
			_board[monsterY][monsterX] = ' ';
			_board[monsterY - 1][monsterX - 1] = 'M';
		}break;
	case 8:
		tile = _board[monsterY - 1][monsterX];
		if (processPlayerMoveF(tile, fight) == true)
		{
			player.setPosition(monsterX, monsterY - 1);
			_board[monsterY][monsterX] = ' ';
			_board[monsterY - 1][monsterX] = 'M';
		} break;
	case 9:
		tile = _board[monsterY - 1][monsterX + 1];
		if (processPlayerMoveF(tile, fight) == true)
		{
			player.setPosition(monsterX + 1, monsterY - 1);
			_board[monsterY][monsterX] = ' ';
			_board[monsterY - 1][monsterX + 1] = 'M';
		}break;
	default:
		break;
}

}
bool Level::processMyMove(Players & player,char tile, bool & fight){
	switch (tile){
	case ' ': return true;
	case '#': return false;
	case '!': return false;
	case '*':
		printf("You found something... looks like cash + 400, +100Hp , +20dmg for all soldiers\n");
		system("PAUSE");
		player.addAtrb(100,20);
		player.substractMoney(400);
		return true;
	case '^': 
		printf("You found something... looks like casg +1000 +300Hp , +50dmg for all soldiers\n");
		system("PAUSE");
		player.addAtrb(300, 50);
		player.substractMoney(1000);
		return true;
	default:fight = true;// battle
		return true;
		break;
	}
}

bool Level::processPlayerMove(char tile){
	switch (tile){
	case ' ': return true;
	case '#': return false;
	case '!': return false;
	case '*': return false;
	case '^': return false;
	case 'M': return false;
	default:;// battle
		break;
	}
	return true;
}
bool Level::processPlayerMoveF(char tile, bool & fight){
	switch (tile){
	case ' ': return true;
	case '#': return false;
	case '!': return false;
	case '*': return false;
	case '^': return false;
	case 'M': return false;
	default: fight = true;// battle
		break;
	}
	return true;
}
void Level::follow(Players & player, Players & enemy, bool & following, bool & fight){
	unsigned playerX, playerY;
	player.getPosition(playerX, playerY);
	unsigned enemyX, enemyY;
	enemy.getPosition(enemyX, enemyY);
	int roznicaX = playerX - enemyX;
	int roznicaY = playerY - enemyY;
	char tile;
	following = false;
	if (roznicaX <= 4 && roznicaX >= -4 && roznicaY <= 4 && roznicaY >= -4){
		following = true;
		//7
		if (playerY < enemyY && playerX < enemyX){
			tile = _board[enemyY - 1][enemyX - 1];
			if (processPlayerMoveF(tile, fight) == true){
				setPoint(enemyX, enemyY, ' ');
				enemy.setPosition(enemyX - 1, enemyY - 1);
				setPoint(enemyX -1  , enemyY -1 , 'M');
			}
		}
		//9
		if (playerY < enemyY && playerX > enemyX){
			tile = _board[enemyY - 1][enemyX + 1];
			if (processPlayerMoveF(tile, fight) == true){
				setPoint(enemyX, enemyY, ' ');
				enemy.setPosition(enemyX + 1, enemyY - 1);
				setPoint(enemyX + 1, enemyY -1 , 'M');
			}
		}
		//1
		if (playerY > enemyY && playerX < enemyX){
			tile = _board[enemyY + 1][enemyX - 1];
			if (processPlayerMoveF(tile, fight) == true){
				setPoint(enemyX, enemyY, ' ');
				enemy.setPosition(enemyX - 1, enemyY + 1);
				setPoint(enemyX -1  , enemyY + 1, 'M');
			}
		}
		//3
		if (playerY > enemyY && playerX > enemyX){
			tile = _board[enemyY + 1][enemyX + 1];
			if (processPlayerMoveF(tile, fight) == true){
				setPoint(enemyX, enemyY, ' ');
				enemy.setPosition(enemyX + 1, enemyY + 1);
				setPoint(enemyX +1 , enemyY + 1, 'M');
			}
		}
		//4
		if (playerY == enemyY && playerX < enemyX){
			tile = _board[enemyY][enemyX - 1];
			if (processPlayerMoveF(tile, fight) == true){
				setPoint(enemyX, enemyY, ' ');
				enemy.setPosition(enemyX - 1, enemyY);
				setPoint(enemyX - 1, enemyY, 'M');
			}
		}
		//6
		if (playerY == enemyY && playerX > enemyX){
			tile = _board[enemyY][enemyX + 1];
			if (processPlayerMoveF(tile, fight) == true){
				setPoint(enemyX, enemyY, ' ');
				enemy.setPosition(enemyX + 1, enemyY);
				setPoint(enemyX + 1, enemyY, 'M');
			}
		}
		//8
		if (playerY < enemyY && playerX == enemyX){
			tile = _board[enemyY - 1][enemyX];
			if (processPlayerMoveF(tile, fight) == true){
				setPoint(enemyX, enemyY, ' ');
				enemy.setPosition(enemyX, enemyY - 1);
				setPoint(enemyX, enemyY -1 , 'M');
			}
		}
		//2
		if (playerY > enemyY && playerX == enemyX){
			tile = _board[enemyY + 1][enemyX];
			if (processPlayerMoveF(tile, fight) == true){
				setPoint(enemyX, enemyY, ' ');
				enemy.setPosition(enemyX, enemyY + 1);
				setPoint(enemyX, enemyY + 1, 'M');
			}
		}
	}
}

// battle

void Level::randomMovePlayer(int &x, int &y,unsigned sx, unsigned sy, unsigned dx, unsigned dy){

	if (dy > sy){
		y = 1;
		x = -1;
		if (_allies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 &&  sx + x != 26)
			return;
		x++;
		if (_allies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;
		x++;
		if (_allies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;
		
	}
	else{
		y = -1;
		x = -1;
		if (_allies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;
		x++;
		if (_allies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;
		x++;
		if (_allies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;

	}
	y = 0;
	x = 0;
	
}
void Level::randomMoveEnemy(int &x, int &y, unsigned sx, unsigned sy, unsigned dx, unsigned dy){
	if (dy > sy){
		y = 1;
		x = -1;
		if (_enemies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;
		x++;
		if (_enemies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;
		x++;
		if (_enemies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;

	}
	else{
		y = -1;
		x = -1;
		if (_enemies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;
		x++;
		if (_enemies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;
		x++;
		if (_enemies[sy + y][sx + x] == 0 && sy + y != 26 && sx + x != 1 && sx + x != 26)
			return;

	}
	y = 0;
	x = 0;

}
void Level::printBattleMap(unsigned playerX, unsigned playerY, unsigned monsterX, unsigned monsterY){
	char tile;
	printf("01234567890123456789012345678901234567890123456789012\n");
	for (unsigned i = 0; i < _board.size(); i++){
		
		for (unsigned j = 0; j < _board[i].size(); j++){
			if (_enemies[i][j] != 0){
				tile = _board[i][j];
				setColor(tile, "red");
				continue;
			}
			if (_allies[i][j] != 0){
				tile = _board[i][j];
				setColor(tile, "green");
				continue;
			}
			if (i == playerY && j == playerX){
				tile = _board[i][j];
				setColor(tile, "violet");
				continue;
			}
			if (i == monsterY && j == monsterX){
				tile = _board[i][j];
				setColor(tile, "violet");
				continue;
			}
			tile = _board[i][j];
			cout << tile;
		}
		printf("%d", i);
		cout << endl;
	}

}
void Level::setFightBoard(Players & player1, Players & player2){
	default_random_engine randomGenerator(time(NULL));
	uniform_int_distribution<int> number(1, 3);

	unsigned playerX, playerY;
	unsigned monsterX, monsterY;
	
	unsigned nm = 0;
	unsigned begin;

	//setting monsters of player1 on battle map

	unsigned units1;
	unsigned temp1[3];
	units1 = player1.getUnits();
	printf("Units player : %d \n", units1);
	_getch();

	player1.getUnits(temp1[0], temp1[1], temp1[2]);

	//hero on mid

	setPoint(ceil((unsigned)(_board[1].size() / 2)), 1, 'P');
	playerY = 1;
	playerX = ceil((unsigned)(_board[1].size() / 2));

	//units on mid
	for (unsigned i = 0; i < 3; i++){
		begin = (unsigned)(_board[i + 2].size() - temp1[2 - i]) / 2;
		for (unsigned j = 0; j < temp1[2 - i]; j++){
			if (i == 0){
				setPoint(begin + j, 4-i, 'S');
				player1.setMonsterPosition(begin + j, 4-i, nm);
				_allies[4-i][begin + j] = nm+1;
				nm++;
			}
			if ( i == 1){
				setPoint(begin + j, 4-i, 'Z');
				player1.setMonsterPosition(begin + j, 4-i, nm);
				_allies[4 - i][begin + j] = nm+1;
				nm++;
			}
			if ( i == 2){
				setPoint(begin + j, 4-i, 'D');
				player1.setMonsterPosition(begin + j, 4-i, nm);
				_allies[ 4- i][begin + j] = nm+1;
				nm++;
			}
		}
	}

	//setting monsters of player2 on battle map
	nm = 0;
	unsigned units2;
	unsigned temp2[3];
	units2 = player2.getUnits();
	player2.getUnits(temp2[0], temp2[1], temp2[2]);
	//hero on mid
	setPoint(ceil((unsigned)(_board[_board.size() - 2].size() / 2)), _board.size() - 2, 'M');
	monsterX = _board.size() - 2;
	monsterY = ceil((unsigned)(_board[_board.size() - 2].size() / 2));
	//units on mid
	for (unsigned i = 0; i < 3; i++){
		begin = (unsigned)(_board[_board.size() - 5 + i].size() - temp2[i]) / 2;
		for (unsigned j = 0; j < temp2[i]; j++){
			if (i == 0){
				setPoint(begin + j, _board.size() - 5 + i, 'S');
				player2.setMonsterPosition(begin + j, _board.size() - 5 + i, nm);
				_enemies[_board.size() - 5 + i][begin + j] = nm+1;
				nm++;
			}
			if (i == 1){
				setPoint(begin + j, _board.size() - 5 + i, 'Z');
				player2.setMonsterPosition(begin + j, _board.size() - 5 + i, nm);
				_enemies[_board.size() - 5 + i][begin + j] = nm+1;
				nm++;
			}
			if (i == 2){
				setPoint(begin + j, _board.size() - 5 + i, 'D');
				player2.setMonsterPosition(begin + j, _board.size() - 5 + i, nm);
				_enemies[_board.size() - 5 + i][begin + j] = nm+1;
				nm++;
			}
		}
	}


	player1.setFightPosition(playerX, playerY);
	player2.setFightPosition(monsterX, monsterY);
	printBattleMap(playerX, playerY, monsterX, monsterY);
	_getch();
}

void Level::processingBattle(Players & player, Players & enemy){
	// looking for the closest
	unsigned units1, tempUnits1 = 0, units2, tempUnits2 = 0;
	unsigned pMonsterX, pMonsterY, eMonsterX, eMonsterY;
	unsigned playerX, playerY, monsterX, monsterY;
	player.getFightPosition(playerX, playerY);
	enemy.getFightPosition(monsterX, monsterY);
	units1 = player.getUnits();
	units2 = enemy.getUnits();
	double dx, dy, d = 0, min = 100;
	
	// player move

	unsigned closest = 0;
	char tile;
	bool dead;
	bool End = false;
	int tempX = 0, tempY = 0;

	
	
	/*printf("\nPlayer units %d : \n", units1);
	player.getMonstersStats();
	printf("\nMonster units %d : \n", units2);
	enemy.getMonstersStats();*/
	
	while (End==false){
		system("cls");
		for (unsigned i = 0; i < units1; i++){

			//checking if soldier is dead
			if (player.checkMonsterDead(i) == true)
				continue;

			tempUnits1++;
			min = 100;



			player.getMonsterPosition(pMonsterX, pMonsterY, i);
			for (unsigned j = 0; j < units2; j++){
				if (enemy.checkMonsterDead(j) == true)
					continue;
				enemy.getMonsterPosition(eMonsterX, eMonsterY, j);
				d = sqrt(pow(pMonsterX + eMonsterX, 2) + pow(pMonsterY + eMonsterY, 2));
				if (d < min){
					min = d;
					closest = j;
				}

			}

			enemy.getMonsterPosition(eMonsterX, eMonsterY, closest);
			//printf("(%d,%d) do (%d,%d) odleglosc : %f\n", pMonsterX, pMonsterY, eMonsterX, eMonsterY, min );


			//7
			if (eMonsterY < pMonsterY && eMonsterX < pMonsterX){
				tile = _board[pMonsterY - 1][pMonsterX - 1];
				if (_enemies[pMonsterY - 1][pMonsterX - 1] != 0){
					enemy.getMonsterAttack(player.attackMonster(i), _enemies[pMonsterY - 1][pMonsterX - 1] - 1, dead);
					if (dead == true){
						_enemies[pMonsterY - 1][pMonsterX - 1] = 0;
						_board[pMonsterY - 1][pMonsterX - 1] = ' ';
						//	enemy.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_allies[pMonsterY - 1][pMonsterX - 1] == 0){
					if (processPlayerMove(tile) == true){
						_allies[pMonsterY][pMonsterX] = 0;
						_allies[pMonsterY - 1][pMonsterX - 1] = i + 1;
						setPoint(pMonsterX, pMonsterY, ' ');
						player.setMonsterPosition(pMonsterX - 1, pMonsterY - 1, i);
						setPoint(pMonsterX - 1, pMonsterY - 1, player.getMonsterMark(i));
					}
					continue;
				}

				randomMovePlayer(tempX, tempY, pMonsterX, pMonsterY, eMonsterX, eMonsterY);
					tile = _board[pMonsterY  + tempY][pMonsterX + tempX];
					if (processPlayerMove(tile) == true){
					_allies[pMonsterY][pMonsterX] = 0;
					_allies[pMonsterY +tempY][pMonsterX  + tempX] = i + 1;
					setPoint(pMonsterX, pMonsterY, ' ');
					player.setMonsterPosition(pMonsterX + tempX, pMonsterY + tempY, i);
					setPoint(pMonsterX + tempX, pMonsterY + tempY, player.getMonsterMark(i));
					}
					
			}
			//9
			if (eMonsterY < pMonsterY && eMonsterX > pMonsterX){
				tile = _board[pMonsterY - 1][pMonsterX + 1];
				if (_enemies[pMonsterY - 1][pMonsterX + 1] != 0){
					enemy.getMonsterAttack(player.attackMonster(i), _enemies[pMonsterY - 1][pMonsterX + 1] - 1, dead);
					if (dead == true){
						_enemies[pMonsterY - 1][pMonsterX + 1] = 0;
						_board[pMonsterY - 1][pMonsterX + 1] = ' ';
						//	enemy.monsterDead(i);
						dead = false;

					}
					continue;
				}
				if (_allies[pMonsterY - 1][pMonsterX + 1] == 0){

					if (processPlayerMove(tile) == true){
						_allies[pMonsterY][pMonsterX] = 0;
						_allies[pMonsterY - 1][pMonsterX + 1] = i + 1;
						setPoint(pMonsterX, pMonsterY, ' ');
						player.setMonsterPosition(pMonsterX + 1, pMonsterY - 1, i);
						setPoint(pMonsterX + 1, pMonsterY - 1, player.getMonsterMark(i));
					}
					continue;

				}
			
				randomMovePlayer(tempX, tempY, pMonsterX, pMonsterY, eMonsterX, eMonsterY);
					tile = _board[pMonsterY + tempY][pMonsterX + tempX];
					if (processPlayerMove(tile) == true){
					_allies[pMonsterY][pMonsterX] = 0;
					_allies[pMonsterY + tempY][pMonsterX + tempX] = i + 1;
					setPoint(pMonsterX, pMonsterY, ' ');
					player.setMonsterPosition(pMonsterX + tempX, pMonsterY + tempY, i);
					setPoint(pMonsterX + tempX, pMonsterY + tempY, player.getMonsterMark(i));
					}
			
			}
			//1
			if (eMonsterY > pMonsterY && eMonsterX < pMonsterX){
				tile = _board[pMonsterY + 1][pMonsterX - 1];
				if (_enemies[pMonsterY + 1][pMonsterX - 1] != 0){
					enemy.getMonsterAttack(player.attackMonster(i), _enemies[pMonsterY + 1][pMonsterX - 1] - 1, dead);
					if (dead == true){
						_enemies[pMonsterY + 1][pMonsterX - 1] = 0;
						_board[pMonsterY + 1][pMonsterX - 1] = ' ';
						//	enemy.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_allies[pMonsterY + 1][pMonsterX - 1] == 0){
					if (processPlayerMove(tile) == true){
						_allies[pMonsterY][pMonsterX] = 0;
						_allies[pMonsterY + 1][pMonsterX - 1] = i + 1;
						setPoint(pMonsterX, pMonsterY, ' ');
						player.setMonsterPosition(pMonsterX - 1, pMonsterY + 1, i);
						setPoint(pMonsterX - 1, pMonsterY + 1, player.getMonsterMark(i));
					}
					continue;
				}

				randomMovePlayer(tempX, tempY, pMonsterX, pMonsterY, eMonsterX, eMonsterY);
					tile = _board[pMonsterY + tempY][pMonsterX + tempX];
					if (processPlayerMove(tile) == true){
					_allies[pMonsterY][pMonsterX] = 0;
					_allies[pMonsterY + tempY][pMonsterX + tempX] = i + 1;
					setPoint(pMonsterX, pMonsterY, ' ');
					player.setMonsterPosition(pMonsterX + tempX, pMonsterY + tempY, i);
					setPoint(pMonsterX + tempX, pMonsterY + tempY, player.getMonsterMark(i));
					}
				
			}
			//3
			if (eMonsterY > pMonsterY && eMonsterX > pMonsterX){
				tile = _board[eMonsterY + 1][eMonsterX + 1];
				if (_enemies[pMonsterY + 1][pMonsterX + 1] != 0){
					enemy.getMonsterAttack(player.attackMonster(i), _enemies[pMonsterY + 1][pMonsterX + 1] - 1, dead);
					if (dead == true){
						_enemies[pMonsterY + 1][pMonsterX + 1] = 0;
						_board[pMonsterY + 1][pMonsterX + 1] = ' ';
						//	enemy.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_allies[pMonsterY + 1][pMonsterX + 1] == 0){
					if (processPlayerMove(tile) == true){
						_allies[pMonsterY][pMonsterX] = 0;
						_allies[pMonsterY + 1][pMonsterX + 1] = i + 1;
						setPoint(pMonsterX, pMonsterY, ' ');
						player.setMonsterPosition(pMonsterX + 1, pMonsterY + 1, i);
						setPoint(pMonsterX + 1, pMonsterY + 1, player.getMonsterMark(i));
					}
					continue;
				}

				randomMovePlayer(tempX, tempY, pMonsterX, pMonsterY, eMonsterX, eMonsterY);
					tile = _board[pMonsterY + tempY][pMonsterX + tempX];
					if (processPlayerMove(tile) == true){
					_allies[pMonsterY][pMonsterX] = 0;
					_allies[pMonsterY + tempY][pMonsterX + tempX] = i + 1;
					setPoint(pMonsterX, pMonsterY, ' ');
					player.setMonsterPosition(pMonsterX + tempX, pMonsterY + tempY, i);
					setPoint(pMonsterX + tempX, pMonsterY + tempY, player.getMonsterMark(i));
					}
				
			}
			//4
			if (eMonsterY == pMonsterY && eMonsterX < pMonsterX){
				tile = _board[pMonsterY][pMonsterX - 1];
				if (_enemies[pMonsterY][pMonsterX - 1] != 0){
					enemy.getMonsterAttack(player.attackMonster(i), _enemies[pMonsterY][pMonsterX - 1] - 1, dead);
					if (dead == true){
						_enemies[pMonsterY][pMonsterX - 1] = 0;
						_board[pMonsterY][pMonsterX - 1] = ' ';
						//enemy.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_allies[pMonsterY][pMonsterX - 1] == 0){
					if (processPlayerMove(tile) == true){
						_allies[pMonsterY][pMonsterX] = 0;
						_allies[pMonsterY][pMonsterX - 1] = i + 1;
						setPoint(pMonsterX, pMonsterY, ' ');
						player.setMonsterPosition(pMonsterX - 1, pMonsterY, i);
						setPoint(pMonsterX - 1, pMonsterY, player.getMonsterMark(i));
					}
					continue;
				}

				randomMovePlayer(tempX, tempY, pMonsterX, pMonsterY, eMonsterX, eMonsterY);
						tile = _board[pMonsterY + tempY][pMonsterX + tempX];
						if (processPlayerMove(tile) == true){
						_allies[pMonsterY][pMonsterX] = 0;
						_allies[pMonsterY + tempY][pMonsterX + tempX] = i + 1;
						setPoint(pMonsterX, pMonsterY, ' ');
						player.setMonsterPosition(pMonsterX + tempX, pMonsterY + tempY, i);
						setPoint(pMonsterX + tempX, pMonsterY + tempY, player.getMonsterMark(i));
						}
						
			}
			//6
			if (eMonsterY == pMonsterY && eMonsterX > pMonsterX){
				tile = _board[pMonsterY][pMonsterX + 1];
				if (_enemies[pMonsterY][pMonsterX + 1] != 0){
					enemy.getMonsterAttack(player.attackMonster(i), _enemies[pMonsterY][pMonsterX + 1] - 1, dead);
					if (dead == true){
						_enemies[pMonsterY][pMonsterX + 1] = 0;
						_board[pMonsterY][pMonsterX + 1] = ' ';
						//enemy.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_allies[pMonsterY][pMonsterX + 1] == 0){
					if (processPlayerMove(tile) == true){
						_allies[pMonsterY][pMonsterX] = 0;
						_allies[pMonsterY][pMonsterX + 1] = i + 1;
						setPoint(pMonsterX, pMonsterY, ' ');
						player.setMonsterPosition(pMonsterX + 1, pMonsterY, i);
						setPoint(pMonsterX + 1, pMonsterY, player.getMonsterMark(i));
					}
					continue;
				}

				randomMovePlayer(tempX, tempY, pMonsterX, pMonsterY, eMonsterX, eMonsterY);
					tile = _board[pMonsterY + tempY][pMonsterX + tempX];
					if (processPlayerMove(tile) == true){
					_allies[pMonsterY][pMonsterX] = 0;
					_allies[pMonsterY + tempY][pMonsterX + tempX] = i + 1;
					setPoint(pMonsterX, pMonsterY, ' ');
					player.setMonsterPosition(pMonsterX + tempX, pMonsterY + tempY, i);
					setPoint(pMonsterX + tempX, pMonsterY + tempY, player.getMonsterMark(i));
					}
					
			}
			//8
			if (eMonsterY < pMonsterY && eMonsterX == pMonsterX){
				tile = _board[pMonsterY - 1][pMonsterX];
				if (_enemies[pMonsterY - 1][pMonsterX] != 0){
					enemy.getMonsterAttack(player.attackMonster(i), _enemies[pMonsterY - 1][pMonsterX] - 1, dead);
					if (dead == true){
						_enemies[pMonsterY - 1][pMonsterX] = 0;
						_board[pMonsterY - 1][pMonsterX] = ' ';
						//	enemy.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_allies[pMonsterY - 1][pMonsterX] == 0){
					if (processPlayerMove(tile) == true){
						_allies[pMonsterY][pMonsterX] = 0;
						_allies[pMonsterY - 1][pMonsterX] = i + 1;
						setPoint(pMonsterX, pMonsterY, ' ');
						player.setMonsterPosition(pMonsterX, pMonsterY - 1, i);
						setPoint(pMonsterX, pMonsterY - 1, player.getMonsterMark(i));
					}
					continue;
				}

				randomMovePlayer(tempX, tempY, pMonsterX, pMonsterY, eMonsterX, eMonsterY);
						tile = _board[pMonsterY + tempY][pMonsterX + tempX];
						if (processPlayerMove(tile) == true){
						_allies[pMonsterY][pMonsterX] = 0;
						_allies[pMonsterY + tempY][pMonsterX + tempX] = i + 1;
						setPoint(pMonsterX, pMonsterY, ' ');
						player.setMonsterPosition(pMonsterX + tempX, pMonsterY + tempY, i);
						setPoint(pMonsterX + tempX, pMonsterY + tempY, player.getMonsterMark(i));
						}
						
			}
			//2
			if (eMonsterY > pMonsterY && eMonsterX == pMonsterX){
				tile = _board[pMonsterY + 1][pMonsterX];
				if (_enemies[pMonsterY + 1][pMonsterX] != 0){
					enemy.getMonsterAttack(player.attackMonster(i), _enemies[pMonsterY + 1][pMonsterX] - 1, dead);
					if (dead == true){
						_enemies[pMonsterY + 1][pMonsterX] = 0;
						_board[pMonsterY + 1][pMonsterX] = ' ';
						//enemy.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_allies[pMonsterY + 1][pMonsterX] == 0){
					if (processPlayerMove(tile) == true){
						_allies[pMonsterY][pMonsterX] = 0;
						_allies[pMonsterY + 1][pMonsterX] = i + 1;
						setPoint(pMonsterX, pMonsterY, ' ');
						player.setMonsterPosition(pMonsterX, pMonsterY + 1, i);
						setPoint(pMonsterX, pMonsterY + 1, player.getMonsterMark(i));
					}
					continue;
				}
				randomMovePlayer(tempX, tempY, pMonsterX, pMonsterY, eMonsterX, eMonsterY);
					tile = _board[pMonsterY + tempY][pMonsterX + tempX];
					if (processPlayerMove(tile) == true){
					_allies[pMonsterY][pMonsterX] = 0;
					_allies[pMonsterY + tempY][pMonsterX + tempX] = i + 1;
					setPoint(pMonsterX, pMonsterY, ' ');
					player.setMonsterPosition(pMonsterX + tempX, pMonsterY + tempY, i);
					setPoint(pMonsterX + tempX, pMonsterY + tempY, player.getMonsterMark(i));
					}
					

			}
			/*cout << " Player ";
			player.printMonster(i);
			printf("(%d,%d) %f\n", eMonsterX, eMonsterY, min);*/
			/*cout << " \n wykonal ruch " << player.getMonsterMark(i) << " z pozycji : " << pMonsterX << " " << pMonsterY << endl;
			_getch();*/
		}
		/*printBattleMap(playerX, playerY, monsterX, monsterY);
		_getch();
		system("cls");*/

		
		//
		for (unsigned i = 0; i < units2; i++){
			if (enemy.checkMonsterDead(i) == true)
				continue;
			tempUnits2++;
			min = 100;
			enemy.getMonsterPosition(eMonsterX, eMonsterY, i);
			for (unsigned j = 0; j < units1; j++){
				if (player.checkMonsterDead(j) == true)
					continue;
				player.getMonsterPosition(pMonsterX, pMonsterY, j);
				d = sqrt(pow(pMonsterX + eMonsterX, 2) + pow(pMonsterY*(-1) + eMonsterY, 2));
				if (d < min){
					min = d;
					closest = j;
				}

			}
			player.getMonsterPosition(pMonsterX, pMonsterY, closest);
			//printf("(%d,%d) do (%d,%d) odleglosc : %f\n", eMonsterX, eMonsterY, pMonsterX, pMonsterY, min);

			//7
			if (pMonsterY < eMonsterY && pMonsterX < eMonsterX){
				tile = _board[eMonsterY - 1][eMonsterX - 1];
				if (_allies[eMonsterY - 1][eMonsterX - 1] != 0){
					player.getMonsterAttack(enemy.attackMonster(i), _allies[eMonsterY - 1][eMonsterX - 1] - 1, dead);
					if (dead == true){
						_allies[eMonsterY - 1][eMonsterX - 1] = 0;
						_board[eMonsterY - 1][eMonsterX - 1] = ' ';
						//	player.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_enemies[eMonsterY - 1][eMonsterX - 1] == 0){
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY - 1][eMonsterX - 1] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX - 1, eMonsterY - 1, i);
						setPoint(eMonsterX - 1, eMonsterY - 1, enemy.getMonsterMark(i));
					}
					continue;
				}
				randomMoveEnemy(tempX, tempY, eMonsterX, eMonsterY, pMonsterX, pMonsterY);
					tile = _board[eMonsterY + tempY][eMonsterX + tempX];
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + tempY][eMonsterX + tempX] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + tempX, eMonsterY + tempY, i);
						setPoint(eMonsterX + tempX, eMonsterY + tempY, enemy.getMonsterMark(i));
					}
			}
			//9
			if (pMonsterY < eMonsterY && pMonsterX > eMonsterX){
				tile = _board[eMonsterY - 1][eMonsterX + 1];
				if (_allies[eMonsterY - 1][eMonsterX + 1] != 0){
					player.getMonsterAttack(enemy.attackMonster(i), _allies[eMonsterY - 1][eMonsterX + 1] - 1, dead);
					if (dead == true){
						_allies[eMonsterY - 1][eMonsterX + 1] = 0;
						_board[eMonsterY - 1][eMonsterX + 1] = ' ';
						//	player.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_enemies[eMonsterY - 1][eMonsterX + 1] == 0){
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY - 1][eMonsterX + 1] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + 1, eMonsterY - 1, i);
						setPoint(eMonsterX + 1, eMonsterY - 1, enemy.getMonsterMark(i));
					}
					continue;
				}
				randomMoveEnemy(tempX, tempY, eMonsterX, eMonsterY, pMonsterX, pMonsterY);
					tile = _board[eMonsterY + tempY][eMonsterX + tempX];
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + tempY][eMonsterX + tempX] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + tempX, eMonsterY + tempY, i);
						setPoint(eMonsterX + tempX, eMonsterY + tempY, enemy.getMonsterMark(i));
					}
			}
			//1
			if (pMonsterY > eMonsterY && pMonsterX < eMonsterX){
				tile = _board[eMonsterY + 1][eMonsterX - 1];
				if (_allies[eMonsterY + 1][eMonsterX - 1] != 0){
					player.getMonsterAttack(enemy.attackMonster(i), _allies[eMonsterY + 1][eMonsterX - 1] - 1, dead);
					if (dead == true){
						_allies[eMonsterY + 1][eMonsterX - 1] = 0;
						_board[eMonsterY + 1][eMonsterX - 1] = ' ';
						//	player.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_enemies[eMonsterY + 1][eMonsterX - 1] == 0){
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + 1][eMonsterX - 1] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX - 1, eMonsterY + 1, i);
						setPoint(eMonsterX - 1, eMonsterY + 1, enemy.getMonsterMark(i));
					}
					continue;
				}
				randomMoveEnemy(tempX, tempY, eMonsterX, eMonsterY, pMonsterX, pMonsterY);
					tile = _board[eMonsterY + tempY][eMonsterX + tempX];
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + tempY][eMonsterX + tempX] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + tempX, eMonsterY + tempY, i);
						setPoint(eMonsterX + tempX, eMonsterY + tempY, enemy.getMonsterMark(i));
					}
			}
			//3
			if (pMonsterY > eMonsterY && pMonsterX > eMonsterX){
				tile = _board[eMonsterY + 1][eMonsterX + 1];
				if (_allies[eMonsterY + 1][eMonsterX + 1] != 0){
					player.getMonsterAttack(enemy.attackMonster(i), _allies[eMonsterY + 1][eMonsterX + 1] - 1, dead);
					if (dead == true){
						_allies[eMonsterY + 1][eMonsterX + 1] = 0;
						_board[eMonsterY + 1][eMonsterX + 1] = ' ';
						//	player.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_enemies[eMonsterY + 1][eMonsterX + 1] == 0){
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + 1][eMonsterX + 1] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + 1, eMonsterY + 1, i);
						setPoint(eMonsterX + 1, eMonsterY + 1, enemy.getMonsterMark(i));
					}
					continue;
				}
				randomMoveEnemy(tempX, tempY, eMonsterX, eMonsterY, pMonsterX, pMonsterY);
					tile = _board[eMonsterY + tempY][eMonsterX + tempX];
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + tempY][eMonsterX + tempX] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + tempX, eMonsterY + tempY, i);
						setPoint(eMonsterX + tempX, eMonsterY + tempY, enemy.getMonsterMark(i));
					}
			}
			//4
			if (pMonsterY == eMonsterY && pMonsterX < eMonsterX){
				tile = _board[eMonsterY][eMonsterX - 1];
				if (_allies[eMonsterY][eMonsterX - 1] != 0){
					player.getMonsterAttack(enemy.attackMonster(i), _allies[eMonsterY][eMonsterX - 1] - 1, dead);
					if (dead == true){
						_allies[eMonsterY][eMonsterX - 1] = 0;
						_board[eMonsterY][eMonsterX - 1] = ' ';
						//	player.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_enemies[eMonsterY][eMonsterX - 1] == 0){
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY][eMonsterX - 1] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX - 1, eMonsterY, i);
						setPoint(eMonsterX - 1, eMonsterY, enemy.getMonsterMark(i));
					}
					continue;
				}
				randomMoveEnemy(tempX, tempY, eMonsterX, eMonsterY, pMonsterX, pMonsterY);
					tile = _board[eMonsterY + tempY][eMonsterX + tempX];
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + tempY][eMonsterX + tempX] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + tempX, eMonsterY + tempY, i);
						setPoint(eMonsterX + tempX, eMonsterY + tempY, enemy.getMonsterMark(i));
					}
			}
			//6
			if (pMonsterY == eMonsterY && pMonsterX > eMonsterX){
				tile = _board[eMonsterY][eMonsterX + 1];
				if (_allies[eMonsterY][eMonsterX + 1] != 0){
					player.getMonsterAttack(enemy.attackMonster(i), _allies[eMonsterY][eMonsterX + 1] - 1, dead);
					if (dead == true){
						_allies[eMonsterY][eMonsterX + 1] = 0;
						_board[eMonsterY][eMonsterX + 1] = ' ';
						//	player.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_enemies[eMonsterY][eMonsterX + 1] == 0){
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY][eMonsterX + 1] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + 1, eMonsterY, i);
						setPoint(eMonsterX + 1, eMonsterY, enemy.getMonsterMark(i));
					}
					continue;
				}
				randomMoveEnemy(tempX, tempY, eMonsterX, eMonsterY, pMonsterX, pMonsterY);
					tile = _board[eMonsterY + tempY][eMonsterX + tempX];
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + tempY][eMonsterX + tempX] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + tempX, eMonsterY + tempY, i);
						setPoint(eMonsterX + tempX, eMonsterY + tempY, enemy.getMonsterMark(i));
					}
			}
			//8
			if (pMonsterY < eMonsterY && pMonsterX == eMonsterX){
				tile = _board[eMonsterY - 1][eMonsterX];
				if (_allies[eMonsterY - 1][eMonsterX] != 0){
					player.getMonsterAttack(enemy.attackMonster(i), _allies[eMonsterY - 1][eMonsterX] - 1, dead);
					if (dead == true){
						_allies[eMonsterY - 1][eMonsterX] = 0;
						_board[eMonsterY - 1][eMonsterX] = ' ';
						//	player.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_enemies[eMonsterY - 1][eMonsterX] == 0){
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY - 1][eMonsterX] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX, eMonsterY - 1, i);
						setPoint(eMonsterX, eMonsterY - 1, enemy.getMonsterMark(i));
					}
					continue;
				}
				randomMoveEnemy(tempX, tempY, eMonsterX, eMonsterY, pMonsterX, pMonsterY);
					tile = _board[eMonsterY + tempY][eMonsterX + tempX];
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + tempY][eMonsterX + tempX] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + tempX, eMonsterY + tempY, i);
						setPoint(eMonsterX + tempX, eMonsterY + tempY, enemy.getMonsterMark(i));
					}
				
			}
			//2
			if (pMonsterY > eMonsterY && pMonsterX == eMonsterX){

				tile = _board[eMonsterY + 1][eMonsterX];
				if (_allies[eMonsterY + 1][eMonsterX] != 0){
					player.getMonsterAttack(enemy.attackMonster(i), _allies[eMonsterY + 1][eMonsterX] - 1, dead);
					if (dead == true){
						_allies[eMonsterY + 1][eMonsterX] = 0;
						_board[eMonsterY + 1][eMonsterX] = ' ';
						//	player.monsterDead(i);
						dead = false;
					}
					continue;
				}
				if (_enemies[eMonsterY + 1][eMonsterX] == 0){
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + 1][eMonsterX] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX, eMonsterY + 1, i);
						setPoint(eMonsterX, eMonsterY + 1, enemy.getMonsterMark(i));
					}
					continue;
				}

				randomMoveEnemy(tempX, tempY, eMonsterX, eMonsterY, pMonsterX, pMonsterY);
					tile = _board[eMonsterY + tempY][eMonsterX + tempX];
					if (processPlayerMove(tile) == true){
						_enemies[eMonsterY][eMonsterX] = 0;
						_enemies[eMonsterY + tempY][eMonsterX + tempX] = i + 1;
						setPoint(eMonsterX, eMonsterY, ' ');
						enemy.setMonsterPosition(eMonsterX + tempX, eMonsterY + tempY, i);
						setPoint(eMonsterX + tempX, eMonsterY + tempY, enemy.getMonsterMark(i));
					}
				

			}
			/*cout << " Monster ";
			enemy.printMonster(i);
			printf("(%d,%d) %f\n", pMonsterX, pMonsterY, min);*/

		}

		printf("\nPlayer %d units : \n", tempUnits1);
		printf("\nMonster %d : \n", tempUnits2);
		if (tempUnits2 == 0){
			printf("\n You won! \n");
			enemy.setDead();
			player.checkAndSortArmy();
			player.substractMoney(enemy.getMoney());
			player.addExp(enemy.getExp());
			player.checkLvlUp();
			_getch();
			break;
			End = true;
		}
		if (tempUnits1 == 0){
			printf("\n You lost! \n");
			player.setDead();
			_getch();
			End = true;
		}
		tempUnits2 = 0;
		tempUnits1 = 0;
		printBattleMap(playerX, playerY, monsterX, monsterY);
		
		
		
	}
}
void Level::FIGHT(Players & player1, Players & player2){
	deleteBoard();
	load("arena.txt");
	fill0();
	setFightBoard(player1, player2);
	processingBattle(player1, player2);
	
}

//MENU

void Level::initShops(){
	//SWORDMASTER
	_shops.push_back(Shop("SWORDMASTER", 5000));
	_shops.back().purchaseItem(Item("Bronze Sword",10,200,5,20));
	_shops.back().purchaseItem(Item("Silver Sword", 10, 400, 10, 60));
	_shops.back().purchaseItem(Item("Gold Sword", 10, 600,15, 140));
	_shops.back().purchaseItem(Item("Holy Sword", 10, 1000, 20, 260));
	_shops.back().purchaseItem(Item("SashaGrey's Sword <==3", 5, 2100, 50, 600));

	//SOLDIERS

	_shops.push_back(Shop("Giorgio Pierdallo", 5000));

	
}
void Level::enterItems(Players & player){
	vector<string> words;
	_shops[0].getItemNames(words);
	words.push_back("Back");
	int place = 0;
	char move;
	bool end = false;
	while (end == false){
		system("cls");
		_shops[0].showItems();
		cout << endl << endl << endl;

		player.printPlayer();

		cout << "\n\n\n\n";
		cout << endl << endl;
		for (unsigned i = 0; i < 6; i++){
			cout << "\t\t\t";
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			cout << words[i]<< endl;
		}

		move = _getch();
		switch (move){

		case 'S':
		case 's':
			if (place <= 4)
				place++;

			break;
		case 'W':
		case 'w':
			if (place >= 1)
				place--;
			break;
		case 13:
			if (place == 0){
				if (player.getMoney() >= 200){
					player.substractMoney(-200);
					player.addAtrb(5, 20);
					continue;
				}
				else
					printf("Not Enough money");
				system("PAUSE");
			}
			if (place == 1){
				if (player.getMoney() >= 400){
					player.substractMoney(-400);
					player.addAtrb(10, 60);
					continue;
					
				}
				else
					printf("Not Enough money");
				system("PAUSE");
			}
			if (place == 2){
				if (player.getMoney() >= 600){
					player.substractMoney(-600);
					player.addAtrb(15, 140);
					continue;
					
				}
				else
					printf("Not Enough money");
				system("PAUSE");
			}
			if (place == 3){
				if (player.getMoney() >= 1000){
					player.substractMoney(-1000);
					player.addAtrb(20, 260);
					continue;

				}
				else
					printf("Not Enough money");
				system("PAUSE");
			}
			if (place == 4){
				if (player.getMoney() >= 2100){
					player.substractMoney(-2100);
					player.addAtrb(50, 600);
					continue;

				}
				else
					printf("Not Enough money");
				system("PAUSE");
			}
			if (place == 5){
				end = true;
			}
			break;
		}

	}
}
void Level::enterSoldiers(Players & player){
	vector<string> words;
	words.push_back("Snake");
	words.push_back("Zombie");
	words.push_back("Dragon");
	words.push_back("Back");
	int place = 0;
	char move;
	bool end = false;
	cout << "\n\n\n\n\n\n\n";
	while (end == false){
		system("cls");
		player.printPlayer();
		for (unsigned i = 0; i < 4; i++){

			cout << "\t\t\t";
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			cout << words[i] << endl;
		}

		move = _getch();
		switch (move){

		case 'S':
		case 's':
			if (place <= 2)
				place++;

			break;
		case 'W':
		case 'w':
			if (place >= 1)
				place--;
			break;
		case 13:
			if (place == 0){
				if (player.getMoney() >= 50){
					if (player.getUnits() == 100){
						cout << "\nYou cant have more than 100 soldiers !!\n";
						system("PAUSE");
						continue;
					}
					if (player.getSnakes() >= 40){
						cout << "\n You can not have more than 40 same type of soldiers\n";
						system("PAUSE");
						continue;
					}
					player.substractMoney(-50);
					player.addSnake();
					continue;

				}
				else
					printf("Not Enough money\n");
				system("PAUSE");
			}
			if (place == 1){
				if (player.getMoney() >= 100 ){
					if (player.getUnits() == 100){
						cout << "\nYou cant have more than 100 soldiers !!\n";
						system("PAUSE");
						continue;
					}
					if (player.getZombies() >= 40){
						cout << "\n You can not have more than 40 same type of soldiers\n";
						system("PAUSE");
						continue;
					}
					player.substractMoney(-100);
					player.addZombie();
					continue;
				}
				else
					printf("Not Enough money\n");
				system("PAUSE");
			}
			if (place == 2){
				if (player.getMoney() >= 150 ){
					if (player.getUnits() == 100){
						cout << "\nYou cant have more than 100 soldiers !!\n";
						system("PAUSE");
						continue;
					}
					if (player.getDragons() >= 40){
						cout << "\n You can not have more than 40 same type of soldiers\n";
						system("PAUSE");
						continue;
					}
					player.substractMoney(-150);
					player.addDragon();
					continue;
				}
				else
					printf("Not Enough money\n");
				system("PAUSE");
			}
			if (place == 3){
				end = true;
			}
			break;
		}

	}
}
void Level::enterShops(Players & player){
	vector<string> words;
	words.push_back(_shops[0].getName());
	words.push_back(_shops[1].getName());
	words.push_back("Back");
	int place = 0;
	char move;
	bool end = false;
	while (end == false){
		system("cls");
		cout << "\n\n\n\n\n\n\n";
		for (unsigned i = 0; i < 3; i++){
			cout << "\t\t\t";
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			cout << words[i] << endl;
		}

		move = _getch();
		switch (move){

		case 'S':
		case 's':
			if (place <= 1)
				place++;

			break;
		case 'W':
		case 'w':
			if (place >= 1)
				place--;
			break;
		case 13:
			if (place == 0){
				enterItems(player);
			}
			if (place == 1){
				enterSoldiers(player);
			}
			if (place == 2){
				end = true;
			}
			break;
		}

	}
}
void Level::Menu(vector<string> words ,Players & player){
	int place = 0;
	char move;
	bool end = false;
	while (end == false){
		system("cls");
		cout << "\n\n\n\n\n\n\n";
		for (unsigned i = 0; i < 3; i++){
			cout << "\t\t\t";
			if (place == i ){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i ){
				setStringColor(words[place], "gold");
				continue;
			}
			if (place == i){
				setStringColor(words[place], "gold");
				continue;
			}
			cout << words[i] << endl;
		}
		
		move = _getch();
		switch (move){

		case 'S':
		case 's':
			if (place <= 1)
				place++;

			break;
		case 'W':
		case 'w':
			if (place >=1)
			place--;
			break;
		case 13:
			if (place == 0){
				player.printPlayer();
				player.printMonsters();
				system("PAUSE");
			}
			if (place == 1){
				enterShops(player);
			}
			if (place == 2){
				end = true;
			}
			break;
		}
		
	}
	
}