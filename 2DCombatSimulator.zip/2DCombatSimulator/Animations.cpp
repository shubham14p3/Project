#include "Animations.h"
#include<iostream>
#include<Windows.h>
#include<conio.h>
#include<algorithm>


Animations::Animations()
{
}

void Animations::bigSign()
{
	string text[12];
	
	text[0] = "   .............................................................................";
	text[1] = "   .............................................................................";
	text[2] = "   .............................................................................";
	text[3] = "   .......:MMMMMD,..........=MMZ........$MMM:...........,NMMZ....$MMMMMMMMM8....";
	text[4] = "   ...=MMD,.......N+.......OM:OM7.......OMN8MN:........DMNNMO....OMN~...........";
	text[5] = "   .=MM..  .ZMMMMMN~.....NMO....DMI.....OMN..?MZ.....IM=..NMO....OMMMMMMMM?.....";
	text[6] = "   ..$MN,........$M=...~NMMMMMMMMMMM....OMN....NMN~NM8....NMO....OMN~...........";
	text[7] = "   ...?MMD,......$M=..,DN~.......,DM+...OMN....=MMMMD,....NMO....OMN~...........";
	text[8] = "   .......~MMMMMZ....:MMO..........?MO..OMN......$M=......NM8....$MMMMMMMMMN....";
	text[9] = "   .............................................................................";
	text[10] = "  .............................................................................";
	text[11] = "  .............................................................................";
	/*

	text[0] = "      ....:MMMMMD,..........=MMZ........$MMM:...........,NMMZ....$MMMMMMMMM8....";
	text[1] = "   ...=MMD,.......N+.......OM:OM7.......OMN8MN:........DMNNMO....OMN~...........";
	text[2] = "   .=MM..  .ZMMMMMN~.....NMO....DMI.....OMN..?MZ.....IM=..NMO....OMMMMMMMM?.....";
	text[3] = "   ..$MN,........$M=...~NMMMMMMMMMMM....OMN....NMN~NM8....NMO....OMN~...........";
	text[4] = "    ..?MMD,......$M=..,DN~.......,DM+...OMN....=MMMMD,....NMO....OMN~...........";
	text[5] = "        ..~MMMMMZ....:MMO..........?MO..OMN......$M=......NM8....$MMMMMMMMMN....";
	*/


	HANDLE color;
	color = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(color, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);

	for (;;){
		if (_kbhit())
			break;
		for (unsigned i = 0; i < 12; i++){
			for (unsigned j = 0; j < text[i].size() - 1; j++){
				swap(text[i][j], text[i][j + 1]);
			}
			printf("%s", text[i].c_str());
		}
		printf("click any button to continue\n");
		Sleep(2);
		system("cls");

	}
	SetConsoleTextAttribute(color, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_RED | FOREGROUND_INTENSITY);
}
void Animations::loading(string text, string Color){
	HANDLE color;
	color = GetStdHandle(STD_OUTPUT_HANDLE);

	if (Color == "red")
		SetConsoleTextAttribute(color, FOREGROUND_RED | FOREGROUND_INTENSITY);
	if (Color == "gold");
	SetConsoleTextAttribute(color, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);

	for (;;){
		if (_kbhit())
			break;
		for (unsigned j = 0; j < text.size() - 1; j++){
			swap(text[j], text[j + 1]);
		}
		printf("%s\r", text.c_str());
		Sleep(40);
	}

	SetConsoleTextAttribute(color, FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_RED | FOREGROUND_INTENSITY);

}