#pragma once
#include"Level.h"
#include"Players.h"
#include"Animations.h"
#include<vector>
using namespace std;

class GameSystem
{
public:
	GameSystem();
	void intro();
	void analizeMap();
	void play();
	//checkers

	void checkPlayers();

private:
	Players _players[100];
	unsigned _pNumber=0;
	Level _level[10];
	Animations _animation;
};

