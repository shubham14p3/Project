#pragma once
#include"Item.h"
#include<list>
#include<string>
#include<conio.h>
#include<vector>

class Shop
{
public:
	Shop(string name, int money);
	~Shop();

	bool purchaseItem(Item newItem);
	void sellItem(int number, Item & newItem);
	void substractMoney(int value){ _money += value; }
	void showItems();

	int getMoney(){ return _money; }
	string getName(){ return _name; }
	void getItemNames(vector<string> & itemNames);
private:
	string _name;
	list<Item> _items;
	int _money;


};

