#pragma once
#include"Monster.h"
#include<string>

using namespace std;
class Players
{
public:
	Players();
	
	//setters
	void setLive(){ _dead = false; }
	void setDead(){ _dead = true; }
	void setStats(string name, unsigned hp, unsigned damage, unsigned units);
	void setPosition(unsigned x, unsigned y);
	void setSoldiers();
	void setMonsterPosition(unsigned x, unsigned y, unsigned nm);
	void setFightPosition(unsigned x, unsigned y);
	void substractMoney(int value){ _money += value; }
	void addExp(int value){ _exp += value; }
	void addAtrb(int hp, int damage);

	//getters
	bool getDead(){ return _dead; }
	int getX(){ return _x;}
	int getY(){ return _y; }
	void getPosition(unsigned &x, unsigned & y);
	void getFightPosition(unsigned &x, unsigned & y);
	void getMonsterPosition(unsigned & x, unsigned & y, unsigned nm);
	unsigned getMonsterX(unsigned number);
	unsigned getMonsterY(unsigned number);
	unsigned getHp(){ return _hp; }
	unsigned getDamage(){ return _damage; }
	unsigned getUnits(){ return _units; }
	string getName(){return _name; }
	void getUnits(unsigned & snakes, unsigned & zombies, unsigned & dragons);
	void getMonstersStats();
	int getExp(){ return _maxExp; }
	int getZombies(){ return _zombies; }
	int getSnakes(){ return _snakes; }
	int getDragons(){ return _dragons; }

	void monsterDead(unsigned & numberOfMonster);
	bool checkMonsterDead(unsigned number);
	void checkAndSortArmy();

	char getMonsterMark( unsigned number);
	char getMark(){ return _name[0]; }
	int getMoney(){ return _money; }

	void addSnake();
	void addZombie();
	void addDragon();

	void checkLvlUp();


	void getMonsterAttack(unsigned attack, unsigned number, bool & dead);
	unsigned attackMonster(unsigned number);
	//checkers
	void printPlayer();
	void printMonsters();
	void printMonster(unsigned number);
	

private:
	string _name;
	int _money;
	bool _dead = false;
	int _exp;
	int _maxExp;
	unsigned _level;
	unsigned _units=0;
	unsigned _dragons=0;
	unsigned _zombies=0;
	unsigned _snakes=0;
	unsigned _hp=0;
	unsigned _damage=0;
	unsigned _x, _fx;
	unsigned _y, _fy;
	Monster monsters[150];
};

