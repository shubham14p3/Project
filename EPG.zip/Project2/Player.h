#ifndef PLAYER_H
#define PLAYER_H
using namespace std;

class Player
{
public:
	Player();
	void init(int level, int health, int attack, int defense, int experience);

	int attack();
	//Setters
	void setPositions(int x, int y);

	void addExperiense(int experience);

	//Getters
	void getPositions(int &x, int &y);
	int takeDamage(int attack);



private:

	//Properties
	int _level;
	int _health;
	int _attack;
	int _defense;
	int _experience;

	//Positions
	int _x;
	int _y;
};

#endif // PLAYER_H
