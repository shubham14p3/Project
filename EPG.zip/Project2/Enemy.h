#pragma once
#include <string>
#include <string>
#include <random>
#include <ctime>


using namespace std;
 class Enemy
{
public:
	Enemy(string name, char tile, int level, int attack, int defense,int health, int experienceValue);
	 
	int attack();
	//Setters
	void setPositions(int x, int y);
	//Getters
	void getPositions(int &x, int &y);

	string getname();

	int takeDamage(int attack);

	char getTile() { return _tile; };

	//Get AI command
	char getMove(int playerX, int playerY);

	
	
	

private:
	string _name;
	char _tile;

	int _level;
	int _attack;
	int _defense;
	int _health;
	int _experienceValue;
	

	//Position
	int _x;
	int _y;
};

