#include "Player.h"
#include<random>
#include<ctime>


using namespace std;
Player::Player()
{
	_x = 0;
	_y = 0;

}

//Initialization the player with properties
void Player::init(int level, int health, int attack, int defense, int experience)
{
	_level = level;
	_health = health;
	_attack = attack;
	_defense = defense;
	_experience = experience;
}

//set the position of the Player
void Player::setPositions(int x, int y)
{
	_x = x;
	_y = y;

}

//get the position of the Player
void Player::getPositions(int &x, int &y)
{
	x = _x;
	y = _y;

}

int Player::attack()
{
	static default_random_engine randomEngine(time(NULL));
	uniform_int_distribution<int> attackRoll(0, _attack);
	return attackRoll(randomEngine);
}

void Player::addExperiense(int experience)
{
	_experience += experience;
	//Level Up
	if (_experience > 50)
	{
		printf("Level Up\n:");
		_experience -= 50;
		_attack += 10;
		_defense += 5;
		_health += 10;
		_level++;
		system("PAUSE");


	}
}

int Player::takeDamage(int attack)
{
	attack -= _defense;

	//check if attack does damage
	if (attack > 0)
	{
		_health -= attack;
		//check if he died
		if (_health <= 0)
		{
			return 1;
		}

	}
	
		return 0;
}
